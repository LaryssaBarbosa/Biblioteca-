﻿
namespace biblioteca
{
    public class Emprestimo
    {
        internal DateTime dtDevolucao;

        internal bool estaDevolvido()
        {
            throw new NotImplementedException();
        }

        internal bool estaDevolvildo()
        {
            throw new NotImplementedException();
        }
    }
}