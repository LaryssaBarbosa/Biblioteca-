﻿
namespace biblioteca
{
    public class Exemplar
    {
        internal bool disponivel;

        internal bool Disponivel()
        {
            throw new NotImplementedException();
        }
    }
}